import React, { useState, useEffect } from 'react';
import api from './api';

const Recommendations = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        const response = await api.get('/recommendations/');
        console.log('Response:', response.data);
        if (Array.isArray(response.data.recommendations)) {
          setRecommendations(response.data.recommendations);
        } else {
          setRecommendations([]);
        }
        setLoading(false);
      } catch (error) {
        console.error('Error fetching recommendations:', error);
        setLoading(false);
      }
    };

    fetchRecommendations();
  }, []); // Empty dependency array ensures this runs only once on mount

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <h1>Your Recommendations</h1>
      {recommendations.length > 0 ? (
        recommendations.map((rec, index) => (
          <div key={index}>
            <p>{rec}</p>
          </div>
        ))
      ) : (
        <p>No recommendations available.</p>
      )}
    </div>
  );
};

export default Recommendations;
