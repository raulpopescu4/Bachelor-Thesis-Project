import React from 'react';
import { Navigate, Link } from 'react-router-dom';
import './Welcome.css';
import './App.css';

function Welcome({ auth }) {
  if (!auth.loggedIn) {
    return <Navigate replace to="/login"/>;
  }

  return (
    <div className="Welcome">
      <header className="welcome-header">
        <div className="navigation">
          <Link to="/recommendations" className="btn">Get Recommendations</Link>
          <Link to="/update-preferences" className="btn">Set Preferences</Link>
          <Link to="/view-preferences" className="btn">See Preferences</Link>
          <Link to="/your-fights" className="btn">View Your Bookmarked Fights</Link>
        </div>
        <div className="user-profile">USER PROFILE</div>
      </header>
      <div className="main-image">
        <img src="path_to_your_large_image.jpg" alt="Main Banner" />
      </div>
      <div className="image-text-button">
        <img src="path_to_additional_image.jpg" alt="Section Image" />
        <div>
          <p>Some text over image</p>
          <button className="btn">Button Over Image</button>
        </div>
      </div>
      <div className="image-text-button">
        <img src="path_to_additional_image.jpg" alt="Section Image" />
        <div>
          <p>Some text over image</p>
          <button className="btn">Button Over Image</button>
        </div>
      </div>
    </div>
  );
}

export default Welcome;
